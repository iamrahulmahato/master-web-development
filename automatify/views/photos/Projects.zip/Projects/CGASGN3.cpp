#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>

void cartesionPixel(float x,float y){
	float mx = getmaxx()/2;
	float my = getmaxy()/2;
	putpixel(mx+x,my-y,GREEN);
}

void quad4(){
	int mx = getmaxx()/2;
	int my = getmaxy()/2;
	line(mx,0,mx,2*my);
	line(0,my,2*mx,my);
}

void main(){
	
	float X1,Y1,X2,Y2;

	printf("Enter two points:");
	printf("Enter (X1,Y1):");
	scanf("%f %f",&X1,&Y1);
	printf("Enter (X2,Y2):");
	scanf("%f %f",&X2,&Y2);

	float dx = X2 - X1;
	float dy = Y2 - Y1;

	float steps = (abs(dx) >= abs(dy)) ? abs(dx) : abs(dy);
	printf("steps :%f dx:%f dy:%f\n",steps,dx,dy);
	
	float inX = dx / steps;
	float inY = dy / steps;
	printf("steps :%f inx:%f iny:%f\n",steps,inX,inY);

	int i = 0;
	scanf("%d",&i);
	int gd,gm;
	gd = DETECT;
	initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
	quad4();

	while(X1 != X2 && Y1 != Y2){
	X1 = (X1+inX);
	Y1 = (Y1+inY);
	
	if(inX == 1) Y1 = floor(Y1);
	else if(inY == 1) X1 = floor(X1);

	cartesionPixel(X1,Y1);
	}

	getch();
	closegraph();
}