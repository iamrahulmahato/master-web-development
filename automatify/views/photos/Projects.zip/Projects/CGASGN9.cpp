#include <stdio.h>
#include <graphics.h>
#include <conio.h>
#include <dos.h>
void main()
{
    int gd, gm;
    gd = DETECT;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    line(160, 250, 110, 350);
    line(160, 250, 210, 350);
    line(135, 300, 185, 300);

    line(250, 250, 250, 350);
    ellipse(245, 270, -90, 90, 50, 30);
    ellipse(245, 320, -90, 90, 50, 30);
    ellipse(400, 300, 90, -90, 60, 50);
    line(450, 250, 450, 355);
    ellipse(450, 300, -90, 90, 60, 50);
    getch();
    closegraph();
}