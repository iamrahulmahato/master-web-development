#include<stdio.h>
#include<conio.h>
#include<graphics.h>

void qdntline(int x1,int y1, int x2, int y2){
	int mx = getmaxx()/2;
	int my = getmaxy()/2;
	line(mx+x1,my-y1,mx+x2,my-y2);	
}

void quad4(){
	int mx = getmaxx()/2;
	int my = getmaxy()/2;
	line(mx,0,mx,2*my);
	line(0,my,2*mx,my);
}

void main(){
	int x1=10,y1=10,x2=90,y2=40;
	int gd,gm;
	gd = DETECT;
	initgraph(&gd,&gm,"C:\\TURBOC3\\BGI");
	quad4();
	qdntline(x1,y1,x2,y2);
	getch();
	closegraph();
}